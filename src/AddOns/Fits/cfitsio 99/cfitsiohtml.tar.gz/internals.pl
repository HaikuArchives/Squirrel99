# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/ffgtis/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffuky/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcdfl/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffchfl/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffp2dx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtbb/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpgpx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghbn/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/ffvers/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/ffirow/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/fftexp/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/ffflmd/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcdw/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffppnx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmkyu/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmcrd/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/ffasfm/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmkyx/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/ffreopen/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgsfx2/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdkey/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgpv/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/ffukyu/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffucrd/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgkls/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffukyx/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgsdt/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdsum/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgsvx2/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffflus/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtrm/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcopy/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffiurl/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdrow/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/fftkey/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdrws/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/ffibin/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffbnfm/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdhdu/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtch/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffurlt/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/fficol/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmrec/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpkyt/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdtdm/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpkyu/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtcl/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmvec/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtcm/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpkyx/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffflnm/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgabc/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtcp/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtcr/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgkey/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffclos/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtcs/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghsp/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffinit/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffiter/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/ffthdu/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffphpr/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmahd/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffphps/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpthp/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcphd/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffp3dx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/FFGTBB/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/FFIROW/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghdn/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdcol/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/fftplt/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghtb/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcnn/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcno/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpunt/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghdt/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffrprt/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcfx/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpdat/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffprec/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcrtb/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtdm/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffppn/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/FFUCRD/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgerr/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcks/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffppr/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpscl/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgmrm/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffphis/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffwldp/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgacl/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgnxk/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgknx/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgsfx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcvx/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpnul/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcv/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcxui/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcx/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgdes/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgics/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/ffiimg/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgmcp/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffphbn/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgsvx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffptbb/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdelt/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgky/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgmsg/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpssx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtmg/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffupch/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffopen/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcls/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/ffupck/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpclu/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpclx/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpkls/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/FFMAHD/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffesum/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpktp/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpprn/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/ffrdef/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffsnul/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/ffikyu/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/ffikyx/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/ffppru/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmnhd/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/FFGCNO/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpprx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmrhd/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgmtf/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/FFPCKS/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcmps/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgpfx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffg2dx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtnm/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffggpx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffvcks/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtvf/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgbcl/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/ffxypx/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgnrw/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcl/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/ffextn/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffitab/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcn/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcpcl/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/ffirec/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgpvx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/FFGICS/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/ffplsw/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmnam/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffmcom/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffomem/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/ffphtb/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/FFPCLS/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpky/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcns/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/ffptdm/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/ffkeyn/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffhdef/;
$ref_files{$key} = "$dir".q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcpky/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgkyn/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcnx/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtop/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcrow/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpsvc/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdt2s/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdrec/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgkyt/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcrd/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcrhd/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffrtnm/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpknx/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgkyx/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgrsz/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgthd/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgmng/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffsrow/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/fficls/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcpdt/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpdes/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/fftrec/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpcom/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghpr/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghps/;
$ref_files{$key} = "$dir".q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/ffghad/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/ffiterget/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/fftscl/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/ffg3dx/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/ffnkey/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffpmsg/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/ffrsim/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/fffrow/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgunt/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/ffiterset/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/ffdtyp/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/ffccol/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgrec/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/fftnul/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgcks/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgtam/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcmsg/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/ffcrim/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/ffgmop/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

1;

