# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/FTGICS/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/FTHDEF/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/FTMREC/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGCNO/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPHPR/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/FTMAHD/;
$ref_files{$key} = "$dir".q|node55.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPREC/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/FTUCRD/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/FTDREC/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGTBS/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/FTVERS/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPCKS/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGREC/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/FTRDEF/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/FTIROW/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGSDT/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPPR/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPSCL/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/FTOPEN/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/FTIREC/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

1;

