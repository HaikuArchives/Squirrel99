# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate labels original text with physical files.


$key = q/FTGICS/;
$external_labels{$key} = "$URL/" . q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/FTMREC/;
$external_labels{$key} = "$URL/" . q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGCNO/;
$external_labels{$key} = "$URL/" . q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPREC/;
$external_labels{$key} = "$URL/" . q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/FTUCRD/;
$external_labels{$key} = "$URL/" . q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGTBS/;
$external_labels{$key} = "$URL/" . q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPCKS/;
$external_labels{$key} = "$URL/" . q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGSDT/;
$external_labels{$key} = "$URL/" . q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPCLS/;
$external_labels{$key} = "$URL/" . q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPPR/;
$external_labels{$key} = "$URL/" . q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPSCL/;
$external_labels{$key} = "$URL/" . q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/FTOPEN/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGHAD/;
$external_labels{$key} = "$URL/" . q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/FTHDEF/;
$external_labels{$key} = "$URL/" . q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/FTMAHD/;
$external_labels{$key} = "$URL/" . q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/FTPHPR/;
$external_labels{$key} = "$URL/" . q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/FTDREC/;
$external_labels{$key} = "$URL/" . q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/FTFROW/;
$external_labels{$key} = "$URL/" . q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/FTVERS/;
$external_labels{$key} = "$URL/" . q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/FTRDEF/;
$external_labels{$key} = "$URL/" . q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/FTGREC/;
$external_labels{$key} = "$URL/" . q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/FTIROW/;
$external_labels{$key} = "$URL/" . q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/FTIREC/;
$external_labels{$key} = "$URL/" . q|node70.html|; 
$noresave{$key} = "$nosave";

1;

